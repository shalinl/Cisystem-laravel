-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 14, 2021 at 03:50 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `exceptiongens`
--

CREATE TABLE `exceptiongens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `exceptiongens`
--

INSERT INTO `exceptiongens` (`id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 15, '2021-06-13 06:35:33', '2021-06-13 06:35:33'),
(2, 15, '2021-06-13 06:35:43', '2021-06-13 06:35:43'),
(3, 15, '2021-06-13 06:35:52', '2021-06-13 06:35:52'),
(4, 15, '2021-06-13 06:37:35', '2021-06-13 06:37:35');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_06_13_035245_add_usertype_to_users', 2),
(5, '2021_06_13_041451_create_useractivity_table', 3),
(6, '2021_06_13_061541_rename_table', 4),
(7, '2021_06_13_105148_create_exceptiongen_table', 5),
(8, '2021_06_13_130030_add_role_to_users', 6);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `useractivities`
--

CREATE TABLE `useractivities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accessibility` double(8,2) NOT NULL,
  `participants` int(11) NOT NULL,
  `price` double(8,2) NOT NULL,
  `ukey` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `delete_status` tinyint(4) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `useractivities`
--

INSERT INTO `useractivities` (`id`, `title`, `type`, `accessibility`, `participants`, `price`, `ukey`, `delete_status`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Explore a park you have never been to before', 'recreational', 0.00, 1, 0.00, '8159356', 1, 15, '2021-06-13 00:52:40', '2021-06-13 09:27:20'),
(2, 'Play a video game', 'recreational', 0.00, 1, 0.00, '5534113', 1, 15, '2021-06-13 00:52:40', '2021-06-13 09:30:28'),
(3, 'Make your own LEGO creation', 'recreational', 0.10, 1, 0.00, '1129748', 0, 15, '2021-06-13 00:52:41', '2021-06-13 00:52:41'),
(4, 'Write a short story', 'recreational', 0.10, 1, 0.00, '6301585', 0, 15, '2021-06-13 00:52:42', '2021-06-13 00:52:42'),
(5, 'Go see a Broadway production', 'recreational', 0.30, 4, 0.80, '4448913', 0, 15, '2021-06-13 00:52:43', '2021-06-13 00:52:43'),
(6, 'Solve a Rubik\'s cube', 'recreational', 0.10, 1, 0.00, '4151544', 0, 15, '2021-06-13 00:52:44', '2021-06-13 00:52:44'),
(7, 'Explore a park you have never been to before', 'recreational', 0.00, 1, 0.00, '8159356', 0, 15, '2021-06-13 00:52:45', '2021-06-13 00:52:45'),
(8, 'Learn how to play a new sport', 'recreational', 0.20, 1, 0.10, '5808228', 0, 15, '2021-06-13 00:52:46', '2021-06-13 00:52:46'),
(9, 'Learn how to beatbox', 'recreational', 1.00, 1, 0.00, '8731710', 0, 15, '2021-06-13 00:52:47', '2021-06-13 00:52:47'),
(10, 'Make a couch fort', 'recreational', 0.08, 1, 0.00, '2352669', 0, 15, '2021-06-13 00:52:47', '2021-06-13 00:52:47'),
(11, 'Plant a tree', 'recreational', 0.30, 1, 0.30, '1942393', 0, 15, '2021-06-13 06:34:30', '2021-06-13 06:34:30'),
(12, 'Paint the first thing you see', 'recreational', 0.20, 1, 0.25, '1162360', 0, 15, '2021-06-13 06:35:33', '2021-06-13 06:35:33'),
(13, 'Start a blog for something you\'re passionate about', 'recreational', 0.10, 1, 0.05, '8364626', 0, 15, '2021-06-13 06:35:43', '2021-06-13 06:35:43'),
(14, 'Buy a new house decoration', 'recreational', 0.30, 1, 0.40, '3456114', 0, 15, '2021-06-13 06:35:51', '2021-06-13 06:35:51'),
(15, 'Draw something interesting', 'recreational', 0.00, 1, 0.00, '8033599', 0, 15, '2021-06-13 06:37:34', '2021-06-13 06:37:34'),
(16, 'Watch a Khan Academy lecture on a subject of your choosing', 'education', 0.00, 1, 0.00, '7154873', 0, 16, '2021-06-13 08:47:21', '2021-06-13 08:47:21'),
(17, 'Learn origami', 'education', 0.30, 1, 0.20, '8394738', 0, 16, '2021-06-13 08:47:22', '2021-06-13 08:47:22'),
(18, 'Learn the NATO phonetic alphabet', 'education', 0.00, 1, 0.00, '6706598', 0, 16, '2021-06-13 08:47:23', '2021-06-13 08:47:23'),
(19, 'Learn how the internet works', 'education', 0.10, 1, 0.00, '9414706', 0, 16, '2021-06-13 08:47:23', '2021-06-13 08:47:23'),
(20, 'Start a webinar on a topic of your choice', 'education', 0.90, 1, 0.00, '6826029', 0, 16, '2021-06-13 08:47:24', '2021-06-13 08:47:24'),
(21, 'Learn how to whistle with your fingers', 'education', 0.00, 1, 0.00, '2790297', 0, 16, '2021-06-13 08:47:25', '2021-06-13 08:47:25'),
(22, 'Learn Javascript', 'education', 0.90, 1, 0.00, '3469378', 0, 16, '2021-06-13 08:47:26', '2021-06-13 08:47:26'),
(23, 'Learn about the Golden Ratio', 'education', 0.20, 1, 0.10, '2095681', 0, 16, '2021-06-13 08:47:26', '2021-06-13 08:47:26'),
(24, 'Learn how the internet works', 'education', 0.10, 1, 0.00, '9414706', 0, 16, '2021-06-13 08:47:27', '2021-06-13 08:47:27'),
(25, 'Learn how to french braid hair', 'education', 0.10, 1, 0.00, '8926492', 0, 16, '2021-06-13 08:47:28', '2021-06-13 08:47:28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `usertype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `usertype`, `role`) VALUES
(15, 'civ', 'civ@gmail.com', NULL, '$2y$10$U.t96t8YsLTGnLjV0jIZY.P6H3oEw7f6EeO5ulkb8fEEPThC3LvB6', NULL, '2021-06-13 00:52:39', '2021-06-13 00:52:39', 'recreational', 'admin'),
(16, 'test', 'test@gmail.com', NULL, '$2y$10$vcigJEFLHb.bVf5VkGQ1M.kxRCVe2Reoy6bHuUvuN7esoKt.eTmLC', NULL, '2021-06-13 08:47:20', '2021-06-13 08:47:20', 'education', 'normal'),
(17, 'test12', 'admin@mat.com', NULL, '$2y$10$Iro..60m1Fb0v0G1B5uqmuc2v44dqOzL28clfPixMTq1GgcuIM8Z.', NULL, '2021-06-13 09:57:28', '2021-06-13 09:57:28', 'social', 'normal');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exceptiongens`
--
ALTER TABLE `exceptiongens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `useractivities`
--
ALTER TABLE `useractivities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `exceptiongens`
--
ALTER TABLE `exceptiongens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `useractivities`
--
ALTER TABLE `useractivities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
