@extends('layouts.app')

@section('content')
<div class="container mt-3">
  <h2>Laravel 6 AJAX Student CRUD Tutorial</h2>
             
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Contact Number</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>John</td>
        <td>Doe</td>
        <td>john@example.com</td>
        <td></td>
      </tr>
      
    </tbody>
  </table>
</div>
@endsection