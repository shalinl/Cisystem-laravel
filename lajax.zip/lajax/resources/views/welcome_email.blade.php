Hello {{ $name }},<br><br>

Welcome to CI.<br><br>

Thank You,<br>
CI