@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="RegisterMsg"></div>
            <div class="row">
                
            </div>
            <div class="row">
                <div class="col-md-10">
       
                </div>
                <div class="col-md-2">
                   @if (!Auth::user()->admin) 
                   <button class="addbtn">ADD </button>  
                   @else
                      <span>Admin</span>
                   @endif 
                </div>
            </div>
            <div>
                  <table id='actTable' width='100%' border="1" style='border-collapse: collapse;'>
                      <thead>
                        <tr>
                          <td>S.no</td>
                          <td>Activity</td>
                          <td>Type</td>
                          <td>Name</td>
                          <td>Participants</td>
                          <td>Accessibility</td>
                          <td>Price</td>
                          <td>Key</td>
                          <td>Action</td>
                        </tr>
                      </thead>
                    </table>
            </div>
        </div>
    </div>
</div>
@endsection
