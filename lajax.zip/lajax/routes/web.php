<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect('login');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/home/getActs/','HomeController@getActs')->name('home.getActs');
Route::get('/home/editAct/{id?}','HomeController@editAct')->name('home.editAct');
Route::post('/home/updateAct/','HomeController@updateAct')->name('home.updateAct');
Route::post('/home/addAct/','HomeController@addAct')->name('home.addAct');
Route::get('/home/deleteAct/{id?}','HomeController@deleteAct')->name('home.deleteAct');


