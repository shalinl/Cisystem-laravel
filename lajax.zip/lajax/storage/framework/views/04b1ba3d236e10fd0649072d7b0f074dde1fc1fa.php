<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>ci</title>

    <link rel="stylesheet" href="<?php echo e(asset("assets/css/bootstrap.min.css")); ?>">
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    
</head>
    
</head>
<body>
    <div id="app">

        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(Auth::check()): ?>
        <input type="hidden" id="crole" name="crole" value="<?php echo e(Auth::user()->role); ?>">
         <?php endif; ?> 
        <main class="py-4">
        <h3 class="p-3 text-center">CI System</h3>
            <?php echo $__env->yieldContent('content'); ?> 
        </main>
    </div>

    <div class="modal fade" id="ajaxModel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="modelHeading">Edit Activity</h4>
            </div>
            <div class="modal-body">
                <form id="ActForm" name="ActForm" class="form-horizontal" action="<?php echo e(route('home.updateAct')); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                   <input type="hidden" name="act_id" id="act_id">
                    <div class="form-group">
                        <label for="name" class="col-sm-2 control-label">Title</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" id="title" name="title" placeholder="Enter Title" value=""  required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Participants</label>
                        <div class="col-sm-12">
                            <input type="number" id="participants" name="participants" required placeholder="Enter participants" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Accessibility</label>
                        <div class="col-sm-12">
                            <input type="text" id="accessibility" name="accessibility" required placeholder="Enter Accessibility" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Price</label>
                        <div class="col-sm-12">
                            <input type="text" id="price" name="price" required placeholder="Enter Price" class="form-control">   
                            </textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Key</label>
                        <div class="col-sm-12">
                            <input type="text" id="key" name="ukey" required placeholder="Enter Key" class="form-control">   
                        </div>
                    </div>

                    <div class="col-sm-offset-2 col-sm-10 text-right">
                     <button type="submit" class="btn btn-primary" id="saveBtn" value="create">Save changes
                     </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<script src="<?php echo e(asset("assets/js/jquery.min.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/popper.min.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/bootstrap.min.js")); ?>"></script>
  <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
$( document ).ready(function() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    var crole = $('#crole').val();
    if(crole=='normal'){
      $('.addbtn').show();
    }
    else{
      $('.addbtn').hide();
    }
    // DataTable
      $('#actTable').DataTable({
          "pageLength": 3,
          'processing': true,
          'serverSide': true,
          "lengthChange":false,
          "searching":false,
          "ordering":false,
          "lengthChange":false,
             ajax: "<?php echo e(route('home.getActs')); ?>",
             columns: [
                { data: 'id' },
                { data: 'title' },
                { data: 'type' },
                { data: 'name' },
                { data: 'participants' },
                { data: 'accessibility' },
                { data: 'price' },
                { data: 'ukey' },
                {    
                    "render": function(data, type, row) {
                      if(crole=='admin'){
                          return '<button class="btn btn-block delebtn" style="background: #ccc;" data-id="'+row.id+'">Delete</button>';
                      }
                      else{
                        return '<button class="btn btn-block editbtn" style="background: #ccc;" data-id="'+row.id+'">Edit</button>';
                      }
                      
                    }   
                 }
                ],
                "fnRowCallback" : function(nRow, aData, iDisplayIndex){      
                          var oSettings = this.fnSettings ();
                           $("td:first", nRow).html(oSettings._iDisplayStart+iDisplayIndex+1);
                           return nRow;
                }
      });

       $('#actTable').on('click', '.editbtn', function(e){
                $('#ajaxModal').remove();
                e.preventDefault();
                var row_id = $(this).data("id");
               
                    $.ajax({
                          data: $(this).data("id"),
                          url: 'home/editAct/'+row_id,
                          type: "GET",
                          dataType: 'json',
                          success: function (data) {
                              $('#act_id').val(data.id);
                              $('#title').val(data.title);
                              $('#participants').val(data.participants);
                              $('#accessibility').val(data.accessibility);
                              $('#price').val(data.price);
                              $('#key').val(data.ukey);
                              $('#ajaxModel').modal('show');
                          },
                          error: function (data) {
                              console.log('Error:', data);
                          }
                    });
         });

        $( document ).on('submit','#ActForm',function(e) {
                    e.preventDefault();
                    var url=$(this).attr('action');
                    $.ajax({
                          data: $(this).serialize(),
                          url: url,
                          type: "post",
                          dataType: 'json',
                          success: function (data) {
                              $('#ajaxModel').modal('hide');
                              $('.RegisterMsg').empty();
                                $('.RegisterMsg').append('<div class="alert alert-success text-center">'+data['message']+'</div>');
                                setTimeout(function(){ 
                                   $('.RegisterMsg').empty();
                                 }, 3000);
                                $('#actTable').DataTable().ajax.reload();
                          },
                          error: function (data) {
                                var errors = data.responseJSON;                       
                                $('.RegisterMsg').empty();
                                $('.RegisterMsg').append('<div class="alert alert-danger text-center errorMsg"></div>');
                                var errorsHtml='';
                                $.each(errors.errors, function( key, value ) {
                                  errorsHtml += '<p >' + value[0] + '</p>';
                                });
                                $('.errorMsg').append(errorsHtml);
                                setTimeout(function(){ 
                                   $('.RegisterMsg').empty();
                                   
                                 }, 3000);
                          }
                    });
        }); 

         $('.addbtn').on('click',function(e){
                e.preventDefault();
                $.ajax({
                    url: 'home/addAct/',
                    type: "post",
                    success: function(response) {
                        if(response.status=='success'){
                              $('.RegisterMsg').empty();
                              $('.RegisterMsg').append('<div class="alert alert-success text-center">'+response.message+'</div>');
                                setTimeout(function(){ 
                                    $('.RegisterMsg').empty();
                                }, 3000);
                              $('#actTable').DataTable().ajax.reload();
                        }
                        else{
                              $('.RegisterMsg').empty();
                              $('.RegisterMsg').append('<div class="alert alert-danger text-center errorMsg">'+response.message+'</div>');
                                setTimeout(function(){ 
                                    $('.RegisterMsg').empty();
                                }, 3000);
                        }
                      
                    }
                });
         });


          $('#actTable').on('click', '.delebtn', function(e){
                e.preventDefault();
                var row_id = $(this).data("id");
                $.ajax({
                    url: 'home/deleteAct/'+row_id,
                    success: function(response) {
                       if(response.status=='success'){
                              $('.RegisterMsg').empty();
                              $('.RegisterMsg').append('<div class="alert alert-success text-center">'+response.message+'</div>');
                                setTimeout(function(){ 
                                    $('.RegisterMsg').empty();
                                }, 3000);
                              $('#actTable').DataTable().ajax.reload();
                        }
                        else{
                              $('.RegisterMsg').empty();
                              $('.RegisterMsg').append('<div class="alert alert-danger text-center errorMsg">'+response.message+'</div>');
                                setTimeout(function(){ 
                                    $('.RegisterMsg').empty();
                                }, 3000);
                        }
                    },
                    fail: function (error) {
                        alert(error);
                    }
                });
         });
});
    
</script>
<?php echo $__env->yieldContent('scripts'); ?>
</html>
<?php /**PATH D:\laravel\lajax\resources\views/layouts/app.blade.php ENDPATH**/ ?>