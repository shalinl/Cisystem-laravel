Hello <?php echo e($name); ?>,<br><br>

Welcome to CI.<br><br>

Thank You,<br>
CI<?php /**PATH D:\laravel\lajax\resources\views/welcome_email.blade.php ENDPATH**/ ?>