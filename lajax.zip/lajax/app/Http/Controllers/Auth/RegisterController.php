<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Useractivity;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Mail;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'usertype' => ['required','string']
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        $this->validator($data);
        $user = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'usertype' => $data['usertype'],
            'role' =>'normal'
        ]);

        /*
        $email_data = array(
            'name' => $data['name'],
            'email' => $data['email'],
        );

        // send email with the template
        Mail::send('welcome_email', $email_data, function ($message) use ($email_data) {
            $message->to($email_data['email'], $email_data['name'])
                ->subject('Welcome to CI')
                ->from('info@ci.com', 'Admin');
        });  */

        return $user;
    }

    protected function registered(\Illuminate\Http\Request $request, $user)
    {
        if ($request->ajax()){

            $re =$this->insertActivity($user);

            if($re){
                return response()->json([
                    'status'=>'success',
                    'message'=>'Ajax Register Successful,it will automatically redirect to home page',
                    'response'=>[
                    'auth' => auth()->check(),
                    'user' => $user,
                    'intended' => $this->redirectPath()],
                ]); 
            }
        }
    }

    protected function insertActivity($user){
                
                $data = $user->toArray(); 
                $count=10;
                for($i=1;$i<=$count;$i++){
                    $api_url = 'http://www.boredapi.com/api/activity?type='.$data['usertype'];
                    $json_data = file_get_contents($api_url);
                    $response_data = json_decode($json_data,true);
                    $actExists = Useractivity::where('id', '=', $data['id'])
                                                ->where('title', '=', $response_data['activity'])
                                                ->where('type', '=', $response_data['type'])
                                                ->where('delete_status',"=", '0')
                                                ->first();
                    if ($actExists === null) {
                       $res = Useractivity::create([
                                'title' => $response_data['activity'],
                                'type' => $data['usertype'],
                                'accessibility' => $response_data['accessibility'],
                                'participants' => $response_data['participants'],
                                'price' => $response_data['price'],
                                'ukey' => $response_data['key'],
                                'user_id' => $data['id']
                            ]);
                       if ($res->exists) {
                           // success
                        } 
                        else {
                            $count +=1; 
                        }
                    } 
                }
                return true; 
    }
}
