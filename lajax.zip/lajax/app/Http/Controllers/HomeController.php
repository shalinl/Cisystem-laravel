<?php

namespace App\Http\Controllers;

use Auth;
use DB;
use Carbon\Carbon;
use App\Useractivity;
use App\User;
use App\Exceptiongen;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    public function getActs(Request $request){

        $cuser = Auth::user();
        $role = $cuser->role;
        $uid = $cuser->id;
        $draw = $request->get('draw');
        $start = $request->get("start");
        $rowperpage = $request->get("length"); // Rows display per page
        $totalRecords=0;
        $totalRecordswithFilter=0;
        $records = array();
        if($role=='normal'){
                $totalRecords = Useractivity::select('count(*) as allcount')->where('user_id',"=", $uid)->where('delete_status',"=", '0')->count();
                $totalRecordswithFilter = Useractivity::select('count(*) as allcount')->where('user_id',"=", $uid)->where('delete_status',"=", '0')->count();
                $records = Useractivity::leftJoin('users', 'useractivities.user_id', '=','users.id')
                        ->where('user_id',"=", $uid)
                        ->where('delete_status',"=", '0')
                        ->skip($start)
                        ->take($rowperpage)
                        ->select('useractivities.*', 'users.name')->get();
        }
        else{
                $totalRecords = Useractivity::select('count(*) as allcount')->where('delete_status',"=", '0')->count();
                $totalRecordswithFilter = Useractivity::select('count(*) as allcount')->where('delete_status',"=", '0')->count();
                $records = Useractivity::leftJoin('users', 'useractivities.user_id', '=','users.id')
                        ->where('delete_status',"=", '0')
                        ->skip($start)
                        ->take($rowperpage)
                        ->select('useractivities.*', 'users.name')->get();

        }

           $response = array(
                "draw" => intval($draw),
                "iTotalRecords" => $totalRecords,
                "iTotalDisplayRecords" => $totalRecordswithFilter,
                "aaData" => $records
             );

             echo json_encode($response);

    }

    public function editAct($id){
        $act = Useractivity::where('id',"=", $id)->where('delete_status',"=", '0')->first();
        return response()->json($act);
    }

    public function updateAct(Request $request){
        $input = $request->all();
        $res = $this->validator($input);
        $cuser = Auth::user();
        if($res->passes()){
            $actExists = Useractivity::where('id', '!=', $input['act_id'])
                                                ->where('title', '=', $input['title'])
                                                ->where('user_id', '=', $cuser->id)
                                                ->where('delete_status',"=", '0')
                                                ->first();
            if ($actExists === null) {

                $update = Useractivity::where('id',$input['act_id'])->update(
                    array(
                        'title'    =>  $input['title'],
                        'participants' => $input['participants'],
                        'accessibility'  => $input['accessibility'],
                        'price' => $input['price'],
                        'ukey' => $input['ukey']
                    )
                );

                if($update){
                    return response()->json([
                        'status'=>'success',
                        'message'=>'Updated Successfully',
                    ]);
                }
            }
        } 
        else{
            
            return response()->json(['status'=>'success','message'=>$res->messages()]);
        }

    }

    public function validator($data)
    {
        return Validator::make($data, [
            'title' => ['required', 'string'],
            'participants' => ['required', 'int'],
            'accessibility' => ['required'],
            'price' => ['required'],
            'ukey' => ['required','string']
        ]);
    }


    public function addAct(Request $request){


        $cuser = Auth::user();
        $uid = $cuser->id;
        //to get the type of user 
        $act = User::where('id',"=", $uid)->first();
        $result = $act->toArray();
        $utype = $result['usertype'];
        $mytime = Carbon::now();
        $mytime->toDateTimeString();
        //to find the number of activities entered by user within 24hrs
        //DB::enableQueryLog();
        $count = Exceptiongen::where('created_at', '<=', $mytime)
                    ->where('user_id', '=', $uid)->count();
        //dd(DB::getQueryLog());
        if($count<2){

            $api_url = 'http://www.boredapi.com/api/activity?type='.$utype;
            $json_data = file_get_contents($api_url);
            $response_data = json_decode($json_data,true);

            $actExists = Useractivity::where('title', '=', $response_data['activity'])
                                     ->where('user_id', '=', $uid)
                                     ->where('delete_status',"=", '0')
                                     ->first();
            if ($actExists === null) {
                    
                    $res = Useractivity::create([
                                'title' => $response_data['activity'],
                                'type' => $utype,
                                'accessibility' => $response_data['accessibility'],
                                'participants' => $response_data['participants'],
                                'price' => $response_data['price'],
                                'ukey' => $response_data['key'],
                                'user_id' => $uid
                            ]);
                       if ($res->exists) {
                                Exceptiongen::create([
                                    'user_id' => $uid
                                ]);
                                return response()->json([
                                    'status'=>'success',
                                    'message'=>'Activity Added Successfully!!',
                                ]);
                        } 
                        else {
                           return response()->json([
                                'status'=>'error',
                                'message'=>'Something Went Wrong',
                            ]);
                        }
            }
            else{
                 return response()->json([
                        'status'=>'error',
                        'message'=>'Activity Exists already. Try again!!',
                    ]);
            }

        }
        else{
                return response()->json([
                        'status'=>'error',
                        'message'=>'You have added two activities already.please try after 24 hours',
                    ]);
        }     

    }

    public function deleteAct($id){
        
   
                $update = Useractivity::where('id',$id)->update(
                    array(
                        'delete_status'    =>  1
                    )
                );

                if($update){
                    return response()->json([
                        'status'=>'success',
                        'message'=>'Removed Successfully',
                    ]);
                }
                else{
                    return response()->json([
                        'status'=>'error',
                        'message'=>'Something went wrong!!',
                    ]);
                } 
            

    }

}
